package br.com.bluebank.controller;

public class Mensagem {
	
		
		private String mensagem = "Ana Carolina";
		
		public String getMensagem(){
			
			return mensagem;
		}
		
		public void setMensagem(String msg){
			this.mensagem  = msg;
		}


}
